# I'm Yossef Essam Fouad, 
<p align="center" >Bioinformatics graduate passionate about AI, machine learning, and data science.</p>
<p align='center'> 
<img src="https://github.com/YossefEFM/images/blob/main/Me.png" width="250" height="250" alt="Yossef Essam Fouad" class="img-fluid rounded-circl">
</p>
<table alt="Contact Details" align="center">
  <tr>
    <td><a href="mailto:youssefessam1269@gmail.com"><img src="https://github.com/YossefEFM/images/blob/main/Email.png" height="40" width="50" alt="Email"></a></td>
    <td><a href="https://t.me/YossefEFM"><img src="https://github.com/YossefEFM/images/blob/main/Telegram.png" height="40" width="50" alt ="Telegram"> </ing></a></td>
    <td><a href="https://www.linkedin.com/in/yossefessam1408/"><img src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" height="35" width="45" alt="LinkedIn Badge"/></td>
    <td><a href="https://api.whatsapp.com/send?phone=201068105975"><img src="https://thefuturevirtualassistant.com/wp-content/uploads/2021/08/whatsapp-bubble.gif" height="40" width="50" alt="Whatsapp Badge"/></td>
    <td><a href="https://www.facebook.com/YossefEFM/">
      <img src = "https://user-images.githubusercontent.com/60184582/206710371-5e9ce41c-1842-41d9-bcf5-c938c5e467f1.png" width = "50" hieght= "40" alt="FaceBook"></a></td>
  </tr>
</table>
<div alt="Resume" align="center"><a href="https://drive.google.com/file/d/1-SBwR5NmWRAfLJP39-kuuChrFzWTvaUu/view?usp=drive_link"><img width="250" align="center" src="https://readme-typing-svg.herokuapp.com?font=&duration=3500&color=FFFF00&background=000000&center=true&vCenter=true&width=225&height=35&lines=%F0%9F%94%B8See+my+Resume%F0%9F%94%B8"/></a></div>
     
